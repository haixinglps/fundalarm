package cn.exrick.manager.service.telegram;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.telegram.telegrambots.bots.DefaultBotOptions;

import cn.exrick.manager.service.RobotService;
import cn.exrick.manager.service.tg.TelegramChannelMonitor;

//@EnableAspectJAutoProxy(proxyTargetClass = true)
//@Configuration
public class TelegramBotConfig {

	@Bean
	@Scope("singleton")
	public TelegramChannelMonitor telegramChannelMonitor(@Value("${telegram.bot.token}") String botToken,
			@Value("${telegram.channel.username}") String channelUsername, RobotService robotService,
			@Qualifier("taskExecutor") Executor taskExecutor) {

//        DefaultBotOptions options = new DefaultBotOptions();
//        options.setMaxThreads(4);
		DefaultBotOptions botOptions = new DefaultBotOptions();
//		botOptions.setProxyType(DefaultBotOptions.ProxyType.SOCKS5);
//		botOptions.setProxyHost("localhost");
//		botOptions.setProxyPort(7890);

		botOptions.setMaxThreads(10); // 并发处理4条消息
		return new TelegramChannelMonitor(botToken, channelUsername, botOptions, robotService, taskExecutor);
	}
}
