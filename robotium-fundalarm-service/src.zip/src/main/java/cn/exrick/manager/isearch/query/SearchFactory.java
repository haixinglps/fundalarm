package cn.exrick.manager.isearch.query;

import cn.exrick.manager.isearch.Isearch;

/**
 * 检索系统工厂
 * 
 * @author guild
 * 
 */
public class SearchFactory {
	
	public static void init() throws Exception {
		Isearch.init();
	}

	public static Search getSearch() throws Exception {
		return new Isearch();
	}

	public static Search getSearch(String sort, int mode) throws Exception {
		return new Isearch(sort, mode);
	}

}
