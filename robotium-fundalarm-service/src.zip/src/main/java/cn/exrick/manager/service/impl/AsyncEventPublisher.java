package cn.exrick.manager.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.meta.api.objects.Update;

//import com.insurance.order.domain.TInsuredOrderEvent;
//import com.insurance.order.service.NoticeService;

import cn.exrick.common.jedis.JedisClient;
import cn.exrick.manager.service.RobotService;
import cn.hutool.core.io.FileUtil;

@Component

public class AsyncEventPublisher {

//    @Autowired  
//    private ApplicationEventPublisher applicationEventPublisher;  

	@Autowired
	JedisClient jedisClient;

	@Resource
	RobotService robotService;

	@Async
	public void publishEventAsync(String info, Update update) {
		String re = robotService.getAllWork(update);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

		String path = "/home/www/data/" + info + "_" + sdf.format(new Date()) + ".txt";
		FileUtil.writeUtf8String(re, path);
		jedisClient.rpush("videos", info + "," + path);

	}

}